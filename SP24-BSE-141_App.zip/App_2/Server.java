import java.io.*;
import java.net.*;
import java.util.Scanner;

class Server extends MessagingApp implements Runnable {
   // MessagingApp m=new MessagingApp();
    /*public void startServer() {
        Thread serverThread = new Thread(new Server());
        serverThread.start();
    }*/
    Contacts reciever;
    Server( Contacts reciever){
        this.reciever=reciever;

    }
    @Override
    public void run() {
        try (ServerSocket ss = new ServerSocket(6666);) {
            System.out.println("Waiting for the Client");
            Socket s = ss.accept();
            System.out.println("Client Connected");
            //for reading
            DataInputStream d = new DataInputStream(s.getInputStream());

            DataOutputStream dout = new DataOutputStream(s.getOutputStream());
            Scanner sc = new Scanner(System.in);

            Thread s_thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    send_msg(sc,dout);
                }
            });
            Thread r_thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    rcv_msgs(d);
                }
            });
            //Thread s_thread = new Thread(() -> send_msg( sc,dout));
           // Thread r_thread = new Thread(() -> rcv_msgs(d));
            s_thread.start();
            r_thread.start();

            s_thread.join();
            r_thread.join();

            //  System.out.println("Ending the Chat");
            System.out.println("Returning to menu");
            d.close();
            dout.close();
        } catch (Exception e) {
            System.out.println("In Server Exception ");
        }
    }

    public void send_msg(Scanner sc, DataOutputStream dout) {
        String msg;
        System.out.println("Write the message : ");
        try {
            while (true) {
                // System.out.print(" Server : ");
                //String
                msg = sc.nextLine();
                System.out.println("Sending message: " + msg + " to " + reciever);
              store_msgs(msg,reciever);
                dout.writeUTF(msg);
                dout.flush();
                if (msg.equalsIgnoreCase("exit")) {
                    System.out.println("Server ended the chat");
                    break;
                }
            }
        } catch (Exception r) {
            System.out.println(r.getMessage());
        }
    }

    public void rcv_msgs(DataInputStream d) {
        String str;
        try {
            while (true) {
                str = (String) d.readUTF();
                System.out.println("Client : "+ str);
                if (str.equalsIgnoreCase("exit")) {
                    System.out.println("Client ended the chat");
                    break;
                }

            }
        } catch (Exception r) {
            System.out.println(r.getMessage());
        }
    }
}

/*public class Server {
    public static void main(String[] args){
        Thread t2=new Thread(new Server_1());
        t2.start();
    }
}*/

