import java.io.*;
import java.net.*;
import java.util.Scanner;
 class Client implements Runnable {
    //192.168.148.223
   // void Msg_display();

   /* public void startClient() {
        Thread clientThread = new Thread(new Client());
        clientThread.start();
    }*/
    @Override
    public void run() {
        try (Socket s = new Socket("192.168.148.231", 6666);) {
            System.out.println("Connected to Server");
            DataOutputStream dout = new DataOutputStream(s.getOutputStream());

            DataInputStream d = new DataInputStream(s.getInputStream());
            Scanner sc = new Scanner(System.in);

             Thread sendThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    sending_msgs(dout, sc);
                }
            });

            // Start the thread for receiving messages
            Thread receiveThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    recieving_msgs(d);
                }
            });

          //  Thread sendThread = new Thread(() -> sending_msgs(dout, sc));
           // Thread receiveThread = new Thread(() -> recieving_msgs(d));


            // Start both threads
            sendThread.start();
            receiveThread.start();

            sendThread.join();
            receiveThread.join();
            System.out.println("Returning to menu");

            dout.close();
            d.close();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }


    public void sending_msgs(DataOutputStream dout, Scanner sc) {
        String input;
        System.out.println("Write the msg : ");
        try {
            while (true) {
                //String
                // System.out.print(" Client : ");
                input = sc.nextLine();
                dout.writeUTF(input);
                dout.flush();
                if (input.equalsIgnoreCase("exit")) {
                    System.out.println("Client ended the chat");
                    break;
                }
            }
        } catch (Exception s) {
            System.out.println(s.getMessage());
        }
    }


    //dout.close();

    //some Server code

    //  DataInputStream d=new DataInputStream(s.getInputStream());
    public void recieving_msgs(DataInputStream d) {
        String str;
        try {
            while (true) {
                str = (String) d.readUTF();
                System.out.println("Server : " + str);
                if (str.equalsIgnoreCase("exit")) {
                    System.out.println("Server ended the chat");
                    break;
                }
            }
        } catch (Exception r) {
            System.out.println(r.getMessage());
        }
    }
}


//System.out.println("Ending the Chat");



/*public class Client{
   // void Msg_display();
    public static void main(String[] arg) {
        // Client_1 c= new Client();
        Thread t=new Thread(new Client_1());
        t.start();

    }
}*/
